<footer class="main-footer">
	<!-- To the right -->
	<div class="pull-right hidden-xs">
		Dashboard Kereta Api Jakarta
	</div>
	<!-- Default to the left -->
	<strong>Copyright &copy; 2020 <a href="#">Arnold Pasaribu</a>.</strong> All rights reserved.
</footer>